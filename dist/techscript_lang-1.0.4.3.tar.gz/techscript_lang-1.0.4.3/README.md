<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:0d0d0d,30:0f0820,65:1a0a40,100:7c3aed&height=210&section=header&text=🐉%20TechScript&fontSize=70&fontColor=c084fc&animation=fadeIn&fontAlignY=42&desc=A%20friendly%20programming%20language%20that%20reads%20like%20plain%20English%20—%20and%20now%20builds%20websites%20too!&descAlignY=65&descColor=9d7ec9&descSize=13" width="100%"/>

</div>

<div align="center">
  <img src="assets/logo.png" alt="TechScript Dragon Logo" width="220"/>
</div>

<br/>

<div align="center">

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&weight=700&size=17&pause=900&color=C084FC&center=true&vCenter=true&width=860&lines=🦀+Native+Rust+VM+—+1+Million+loops+in+2.9s;tech+run+hello.txs+→+Hello%2C+World!+🐉;use+web+→+Full+website.+Zero+HTML%2FCSS%2FJS.;pip+install+techscript-lang+→+Works+everywhere;150%2B+Built-in+Functions.+crypto.*+math.*+fs.*;Zero+Dependencies.+Blazing+Fast.+One+Binary.+⚡)](https://git.io/typing-svg)

</div>

<div align="center">

![version](https://img.shields.io/badge/version-v1.0.4.3-7c3aed?style=for-the-badge)
![runtime](https://img.shields.io/badge/runtime-Native_Rust_VM-f97316?style=for-the-badge&logo=rust&logoColor=white)
![platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux%20%7C%20Android-22c55e?style=for-the-badge)
![license](https://img.shields.io/badge/license-MIT-3b82f6?style=for-the-badge)

</div>

<div align="center">

![deps](https://img.shields.io/badge/dependencies-NONE-00ff88?style=for-the-badge)
![stdlib](https://img.shields.io/badge/stdlib-150%2B_functions-7c3aed?style=for-the-badge)
![vscode](https://img.shields.io/badge/VS_Code-Extension_v1.0.3-007ACC?style=for-the-badge&logo=visualstudiocode&logoColor=white)
[![Author](https://img.shields.io/badge/Made_by-Tcode--Motion-181717?style=for-the-badge&logo=github)](https://github.com/Tcode-Motion)
[![Stars](https://img.shields.io/github/stars/Tcode-Motion/techscript?style=for-the-badge&color=yellow&label=⭐)](https://github.com/Tcode-Motion/techscript/stargazers)

</div>

---

<div align="center">

```
╔═════════════════════════════════════════════════════════════════════════╗
║                                                                         ║
║   No semicolons. No brackets. No confusing symbols.                     ║
║   No Python runtime. No dependencies. Just pure speed.                  ║
║   Powered by a Native Rust VM.  — Tcode-Motion ⚡                       ║
╚═════════════════════════════════════════════════════════════════════════╝
```

</div>

---

## 🤔 What is TechScript? (Explain Like I'm 10)

Imagine you want to tell a computer to do something. Normally, computers only understand confusing code like this:

```javascript
const x = document.getElementById('name');
if (x !== null && x.value.length > 0) { ... }
```

**TechScript makes that feel like writing a sentence:**

```
make name = ask "What is your name? "
say f"Hello, {name}!"
```

That's it. **No semicolons. No brackets. No confusing symbols.** Just simple words that make sense.

TechScript is:
- 🟢 **A programming language** — you can write code that runs on your computer natively
- 🌐 **A web builder** — you can build full websites with it (no HTML or CSS needed!)
- 🦀 **Powered by Native Rust** — blazing fast compilation, completely independent of Python
- 📦 **One command** — `tech run yourfile.txs` and your program runs instantly into bytecodes

---

## 🚀 What Can TechScript Do?

| What you want to do | TechScript can do it? |
|:---|:---|
| Print text to screen | ✅ `say "Hello!"` |
| Ask the user a question | ✅ `make answer = ask "Your name? "` |
| Do math | ✅ `say 10 + 5 * 2` |
| Make decisions | ✅ `when age > 18 { say "Adult" }` |
| Loop (repeat stuff) | ✅ `each i in 1..10 { say i }` |
| Make functions (reusable code) | ✅ `build greet(name) { say f"Hi {name}!" }` |
| Make classes/objects | ✅ `model Dog { ... }` |
| Handle errors | ✅ `attempt { ... } catch err { ... }` |
| Build a website | ✅ `use web` + `page.run()` |
| Replace HTML | ✅ `page.h1("Title")`, `page.div([...])` |
| Replace CSS | ✅ `page.style("body", { "color": "white" })` |
| Replace JavaScript | ✅ `page.script("function hello() {...}")` |
| **Animation Studio** | ✅ **`anime.*` module (New v2.0!)** |
| **Motion Design** | ✅ **Cinema Edition v7.0 Support** |
| Replace React/Vue | ✅ Built-in state management via JS in `page.script()` |
| Encrypt data (SHA-256, MD5) | ✅ `crypto.sha256("hello")` |
| Read/write files | ✅ `fs.read("file.txt")` |
| Get OS info / env vars | ✅ `os.env_get("PATH")` |
| Parse/encode JSON | ✅ `json.encode(data)` |
| Advanced math (trig, stats) | ✅ `math.sin(3.14)`, `math.factorial(10)` |
| Generate UUID / random | ✅ `random.uuid()`, `random.choice(list)` |
| Get date/time/unix | ✅ `date.now()`, `date.unix()` |
| Run code instantly (no file) | ✅ `tech eval "say 42"` |

---

## 📦 Installation

### 🪟 Install on Windows (Easy — No Python or Terminal Needed!)

#### Option 1: One-Click Installer *(Recommended for Beginners)*

1. Go to the [📥 Releases page](../../releases/latest)
2. Download **`setup.exe`**
3. Double-click it — it will install everything automatically!
4. Open **PowerShell** (`Win + X` → "Windows PowerShell") and type:

```
tech version
```

You should see: `TechScript v1.0.4.3` 🎉

**What the installer does automatically:**
- ✅ Puts `tech.exe` on your computer
- ✅ Makes the `tech` command available everywhere in your terminal
- ✅ Registers `.txs` files so they know they belong to TechScript
- ✅ Installs the VS Code extension for syntax highlighting

#### Option 2: Using pip *(Cross-Platform Wrapper)*

```powershell
pip install techscript-lang
```

---

### 🐧 Install on Linux (Ubuntu, Kali, Debian, Arch)

> **No Python required to install or run!**

**One-line installer:**
```bash
curl -fsSL https://raw.githubusercontent.com/Tcode-Motion/techscript/main/scripts/install.sh | bash
```

**Using APT (Debian/Ubuntu):**
```bash
sudo apt update
sudo apt install techscript
```

---

### 🍎 Install on macOS

> **No Python required to install or run!**

```bash
# Using Homebrew:
brew install tcode-motion/techscript/techscript

# OR use the one-line installer:
curl -fsSL https://raw.githubusercontent.com/Tcode-Motion/techscript/main/scripts/install.sh | bash
```

---

### 📱 Install on Android (Termux)

> *Note: Termux only requires Python to run the pip installer package. You do NOT need Python to actually execute TechScript!*

**Super-Fast One-Liner:**
```bash
pkg install python -y && pip install techscript-lang
tech version
```

> 📖 See [docs/TERMUX.md](docs/TERMUX.md) for the full Android guide.

---

### 🌍 Platform Support

| Platform | Status | Install Method |
|:---|:---:|:---|
| **Windows 10/11** | ✅ Fully supported | `setup.exe` or `pip` |
| **macOS** | ✅ Fully supported | `install.sh` or `brew` |
| **Linux** (Ubuntu, Kali, Arch) | ✅ Fully supported | `install.sh` or `apt` |
| **Android (Termux)** | ✅ Works | `pkg install techscript` |

---

## ✏️ Your First TechScript Program

Create a new file called `hello.txs` (you can use Notepad, VS Code, or any text editor):

```
# This is a comment — the computer ignores it
# The 'say' keyword means "print this to the screen"

say "Hello, World!"
say "I am learning TechScript!"
say "It is very easy to read 😊"
```

Now run it:
```
tech run hello.txs
```

**Output:**
```
Hello, World!
I am learning TechScript!
It is very easy to read 😊
```

---

## 📖 Language Guide (With Explanations for Beginners)

### 📦 Variables — Storing Information

A variable is like a box where you put something to use later.

```
# 'make' creates a new box called 'name' and puts "Alice" inside
make name = "Alice"

# 'keep' creates a CONSTANT — a box you can NEVER change
keep PI = 3.14159

# You can store numbers, text, lists, anything!
make age = 25
make items = [1, 2, 3, 4, 5]      # A list (like a shopping list)
make info = { "city": "Delhi" }    # A dictionary (like a phone book)
```

---

### 🖨️ Output — Talking to the User

```
say "Hello!"                        # Prints: Hello!
say "Name:", name                   # Prints: Name: Alice
say f"My name is {name}!"          # f-strings insert variables: My name is Alice!
say 10 + 5                          # Prints: 15
```

---

### 💬 Input — Asking the User a Question

```
make name = ask "What is your name? "
say f"Nice to meet you, {name}!"
```

When run, it pauses and waits for the user to type something.

---

### 🔀 Conditions — Making Decisions

Think of this like: "IF this is true, do that. Otherwise, do this other thing."

```
make age = 20

when age >= 18 {
    say "You are an adult!"
} or when age >= 13 {
    say "You are a teenager!"
} else {
    say "You are a child!"
}
```

---

### 🔁 Loops — Doing Things Repeatedly

**`each` loop** — do something for every item in a list:

```
# Count from 1 to 5
each i in 1..5 {
    say f"Count: {i}"
}

# Go through each item in a list
each fruit in ["apple", "banana", "mango"] {
    say f"I like {fruit}!"
}
```

**`repeat` loop** — keep doing something while a condition is true:

```
make x = 1
repeat x <= 5 {
    say x
    x = x + 1
}
```

**`stop` and `skip`** — break out of or skip iterations (fixed in v1.0.3!):

```
each i in 1..10 {
    when i == 5 { stop }   # break out of the loop
    when i == 3 { skip }   # skip this iteration (continue)
    say i
}
```

---

### 🔧 Functions — Reusable Code Blocks

A function is a piece of code you write once and can use many times.

```
# 'build' creates a function. 'name' is the input it receives.
build greet(name, greeting = "Hello") {
    say f"{greeting}, {name}!"
}

# Call the function:
greet("Alice")             # Prints: Hello, Alice!
greet("Bob", "Hi there")  # Prints: Hi there, Bob!
greet("Charlie", "Hey")   # Prints: Hey, Charlie!
```

---

### 🏗️ Classes — Blueprints for Objects

A class is like a blueprint for creating things (called objects).

```
# Define what a "Dog" is
model Dog {
    build init(self, name, breed) {
        self.name = name      # Every dog has a name
        self.breed = breed    # Every dog has a breed
    }
    build speak(self) {
        say f"{self.name} says: Woof! Woof!"
    }
    build info(self) {
        say f"{self.name} is a {self.breed}"
    }
}

# Create two dogs (two "objects" from the Dog blueprint)
make rex = Dog("Rex", "German Shepherd")
make buddy = Dog("Buddy", "Golden Retriever")

rex.speak()     # Rex says: Woof! Woof!
rex.info()      # Rex is a German Shepherd
buddy.speak()   # Buddy says: Woof! Woof!
```

---

### ⚠️ Error Handling — Catching Mistakes Gracefully

What if something goes wrong? Instead of crashing, you can handle it:

```
attempt {
    # Try to do this risky thing
    make result = 10 / 0      # Division by zero!
} catch err {
    # If anything goes wrong, come here instead of crashing
    say f"Oops! Something went wrong: {err.message}"
}

say "Program continues normally after the error!"
```

---

### 🔍 New Operators — `in` and `typeof`

**`in` operator** — check if something is inside a list, string, map, or range:

```
make fruits = ["apple", "banana", "mango"]
when "apple" in fruits {
    say "Found it!"
}

when "ello" in "Hello" {
    say "Substring found!"
}
```

**`typeof` operator** — get the type of any value:

```
make x = 42
say typeof x         # int

make name = "Alice"
say typeof name      # str

make items = [1, 2]
say typeof items     # list
```

---

## 🌐 Building Websites with TechScript (New in v1.0.1!)

This is the most exciting feature — you can build a **complete running website** using only TechScript. No HTML. No CSS. No JavaScript files. Just one `.txs` file!

### How it works

1. Write `use web` at the top — this loads the web module
2. Create a page with `make page = WebPage("My Title")`
3. Add styling, content, and scripts
4. Call `page.run()` — your browser opens automatically! 🚀

### Simple Website Example

```
use web

# Create a page with a title
make page = WebPage("My First Website")

# Add CSS styles (like a style sheet)
page.style("body", {
    "background": "#0f0f11",     # Dark background
    "color": "#eeeeee",          # White text
    "font-family": "sans-serif", # Clean font
    "text-align": "center",
    "padding": "60px"
})

# Add JavaScript (for interactive buttons)
page.script("""
    function sayHello() {
        alert('Hello from TechScript! 🐉');
    }
""")

# Build the page layout
page.body([
    page.h1("Welcome to My Website! 🐉"),
    page.p("This website was built 100% in TechScript."),
    page.p("No HTML. No CSS files. No React. Just TechScript!"),
    page.button("Click Me!", { "onclick": "sayHello()" })
])

# Run the server — browser opens automatically!
page.run()
```

**Run it:**
```
tech run my_website.txs
```

That's it! Your browser opens and shows your website. Press `Ctrl+C` to stop the server.

---

## ⚡ Standard Library — 150+ Built-in Functions (New in v1.0.3!)

TechScript v1.0.3 ships with a massive built-in standard library. No imports from the internet needed — everything is baked into the binary.

### 🔢 `math.*` — 38+ Advanced Math Functions

```
say math.sin(3.14159)          # Sine
say math.cos(0)                # Cosine
say math.log(100, 10)          # Logarithm
say math.factorial(10)         # 3628800
say math.gcd(48, 18)           # 6
say math.mean([1, 2, 3, 4, 5]) # 3.0
say math.sqrt(144)             # 12.0
say math.TAU                   # 6.283185...
```

### 🔐 `crypto.*` — Real Cryptography

```
say crypto.sha256("hello")            # FIPS 180-4 SHA-256
say crypto.md5("hello")               # MD5 hash
say crypto.base64_encode("TechScript") # Base64 encode
say crypto.base64_decode("VGVjaFNjcmlwdA==") # Base64 decode
```

### 📄 `json.*` — JSON Encode / Decode

```
make data = { "name": "Alice", "age": 25 }
say json.encode(data)           # {"name":"Alice","age":25}
say json.encode_pretty(data)    # Pretty-printed JSON
make parsed = json.decode('{"x": 1}')
say parsed["x"]                 # 1
```

### 📁 `fs.*` — File System (20+ Functions)

```
fs.write("hello.txt", "Hello, World!")
say fs.read("hello.txt")         # Hello, World!
say fs.exists("hello.txt")       # true
fs.append("hello.txt", "\nMore!")
say fs.size("hello.txt")         # file size in bytes
say fs.list_dir(".")             # list files in current directory
fs.copy("hello.txt", "copy.txt")
```

### 💻 `os.*` — OS Integration (10+ Functions)

```
say os.name()                   # windows / linux / macos
say os.arch()                   # x86_64
say os.pid()                    # process ID
say os.env_get("PATH")          # read environment variable
os.system("echo Hello from OS!")
make result = os.popen("dir")   # capture command output
```

### 🎲 `random.*` — Random & UUID

```
say random.random()             # float between 0.0 and 1.0
say random.randint(1, 100)      # random integer
say random.uuid()               # UUID4 string
say random.choice(["a","b","c"]) # random item from list
make shuffled = random.sample([1,2,3,4,5], 3)
```

### 📅 `date.*` — Date & Time

```
say date.now()    # 2025-03-12 14:30:00
say date.year()   # 2025
say date.month()  # 3
say date.day()    # 12
say date.hour()   # 14
say date.minute() # 30
say date.unix()   # unix timestamp in seconds
```

---

## 🛠️ All CLI Commands

| Command | What it does | Example |
|:---|:---|:---|
| `tech run file.txs` | Run a TechScript file | `tech run hello.txs` |
| `tech run file.txs --debug` | Run with debug info | `tech run calc.txs --debug` |
| `tech check file.txs` | Check for errors without running | `tech check myapp.txs` |
| `tech eval "code"` | ⚡ **NEW** — run inline code instantly | `tech eval "say 42"` |
| `tech "[[[code]]]"` | ⚡ **NEW** — shorthand inline execution | `tech "[[[say 'hi']]]"` |
| `tech repl` | Open interactive mode (type and run live) | `tech repl` |
| `tech transpile file.txs` | Convert your code to Python | `tech transpile hello.txs` |
| `tech version` or `tech -V` | Show installed version | `tech -V` |

---

## 📋 All Example Programs

| File | What it does | Run it |
|:---|:---|:---|
| `examples/hello.txs` | Prints Hello World | `tech run examples/hello.txs` |
| `examples/fibonacci.txs` | Calculates Fibonacci numbers | `tech run examples/fibonacci.txs` |
| `examples/fizzbuzz.txs` | The classic FizzBuzz challenge | `tech run examples/fizzbuzz.txs` |
| `examples/classes.txs` | Dogs and cats using OOP | `tech run examples/classes.txs` |
| `examples/calculator.txs` | Simple calculator | `tech run examples/calculator.txs` |
| `examples/guessing_game.txs` | Guess the number game | `tech run examples/guessing_game.txs` |
| `examples/07_performance_test.txs` | **1-Million Iteration Native VM Benchmark** | `tech run examples/07_performance_test.txs` |
| `examples/web_app_simple.txs` | Simple dark-theme website | `tech run examples/web_app_simple.txs` |
| `examples/web_complete.txs` | Full showcase: counter, API, form | `tech run examples/web_complete.txs` |
| ⚡ `examples/08_math_module.txs` | **NEW** — Math module: trig, roots, factorial, stats | `tech run examples/08_math_module.txs` |
| ⚡ `examples/09_string_ops.txs` | **NEW** — String operations: upper/lower/split/join | `tech run examples/09_string_ops.txs` |
| ⚡ `examples/10_json_module.txs` | **NEW** — JSON encode/decode/pretty-print | `tech run examples/10_json_module.txs` |
| ⚡ `examples/11_crypto_module.txs` | **NEW** — SHA-256, Base64, MD5 | `tech run examples/11_crypto_module.txs` |
| ⚡ `examples/12_date_module.txs` | **NEW** — Date/time/unix timestamps | `tech run examples/12_date_module.txs` |
| ⚡ `examples/13_fs_module.txs` | **NEW** — File read/write/delete/list | `tech run examples/13_fs_module.txs` |
| ⚡ `examples/14_os_module.txs` | **NEW** — OS info, env vars, system commands | `tech run examples/14_os_module.txs` |
| ⚡ `examples/15_random_module.txs` | **NEW** — Random numbers, UUID, choice | `tech run examples/15_random_module.txs` |
| ⚡ `examples/16_control_flow_fix.txs` | **NEW** — stop/skip/in/typeof demos | `tech run examples/16_control_flow_fix.txs` |
| ⚡ `examples/17_inline_eval.txs` | **NEW** — Inline code execution howto | `tech run examples/17_inline_eval.txs` |

---

## 🎬 Cinema Edition Animation Studio (New in v2.0!)

TechScript v2.0 introduces the **Cinema Edition Animation Studio**, a professional-grade motion design environment built directly into the language. With 3D-simulated physics, 20+ cinematic presets, and 10+ complex geometries (including Mobius strips and Black Holes), it's the ultimate tool for visual storytelling.

### 📹 **Studio Showcase**
![TechScript Cinema Edition Showcase](assets/demo.webp)

**Key Features:**
- **20+ Cinematic Presets**: Black Hole Vortex, Solar System, Hypno-Spiral, and more.
- **10+ Complex Geometries**: Mobius Strip, 3D Solar Core, Hexagons, and Stars.
- **3D Kinematics**: Real-time control over Perspective, Rotation X/Y, and Scale Focus.
- **Visual Compiler**: Instantly exports your design to production-ready TechScript code.

**Try it now:**
```powershell
tech run examples/animation_studio.txs
```

---

## 🎨 VS Code / Cursor Editor Extension

### 🐉 Direct Download Link
*   **[Download TechScript v1.0.4.3 VS Code Extension (.vsix)](techscript-1.0.4.3.vsix)**

**Method 1 — Command line (fastest):**
```bash
code --install-extension techscript-1.0.4.3.vsix
```

**Method 2 — Using the GUI:**
1. Open VS Code
2. Press `Ctrl+Shift+X` to open Extensions
3. Click the `···` menu (top right of the Extensions panel)
4. Select **"Install from VSIX..."**
5. Choose [techscript-1.0.4.3.vsix](techscript-1.0.4.3.vsix)

> After installing, all your `.txs` files will have the dragon icon and coloured syntax! 🎨

---

## 🔄 The Evolution of TechScript: v1.0.3 → v1.0.4 → v1.0.4.3

| Feature / Category | TechScript v1.0.3 | TechScript v1.0.4 | TechScript v1.0.4.3 (Latest) |
|:---:|:---:|:---:|:---:|
| **Engine** | Optimized Rust VM | Refined Runtime | **Cinematic Motion Engine** |
| **Speed** | ⚡ Ultra-Fast | ⚡ Turbo-Boosted | **⚡ Maximum Benchmarks** |
| **StdLib Functions** | 150+ Full StdLib | 165+ Functions | **180+ (Added `anime.*`)** |
| **Animation Engine** | Basic CSS | Improved UI | **Professional 3D Studio** |
| **3D Support** | None | Prototype | **Mobius / Black Hole / Solar Core** |
| **Layout Safety** | Basic | Refined | **Fixed 100vh Viewport Grid** |
| **Visual Prototyping**| Minimal | Draft Layout | **Real-Time Visual Compiler** |
| **Binary Size** | ~2.8 MB | ~3.0 MB | **~3.2 MB (Full Cinema Suite)** |
| **OS Integration** | None | None | **os.*** (Env, System, Popen) |
| **Random/UUID** | None | Basic random | **random.*** (UUID, Choice, Shuffle) |
| **Dates/Unix** | None | None | **date.*** (Now, Unix, ms timing) |
| **Control Flow** | Basic | ❌ Broken break/continue | ✅ **Fixed stop/skip** |
| **Operators** | Basic | Basic | **ADDED** `in` & `typeof` |
| **Inline Mode** | File-only | File-only | **ADDED** `tech eval` (one-liners) |
| **Binary Size** | N/A (Python) | ~2.5 MB | **~2.8 MB (Native MSVC Build)** |
| **Safety** | Python-inherited | ❌ Unsafe Transmute | ✅ **100% Type-Safe Bytecode** |
| **Installation** | Complex (Python dep) | Setup.bat (Risky PATH) | **Setup.bat (Fixed Safe PATH)** |

---

## ✨ v1.0.3 Changelog — Security & Power Overhaul

### 🔐 Critical Safety Fixes

- **Eliminated `unsafe` UB** — The VM's bytecode decoder now uses safe `TryFrom<u8>` instead of `unsafe { mem::transmute }`. Corrupt bytecode produces a clean error, not a crash.
- **Fixed Windows installer** — `setup.bat` no longer destroys your PATH if it's over 1,024 characters. Now uses PowerShell's `.NET` API with no size limit.

### ✅ Language Features Fixed

- **`stop` and `skip` now actually work** — Previously `break` compiled to a `return` statement (completely wrong). Now emits a proper forward jump patched at loop end.
- **`in` operator** — `x in list`, `x in map`, `"sub" in str`, `x in range` now all work correctly.
- **`typeof x`** — Returns the actual type name string (`"int"`, `"str"`, `"list"`, etc.)

### ⚡ New Features

- **Inline Execution** — `tech eval "say 42"` or `tech "[[[say 42]]]"` runs code instantly without a file.
- **150+ Built-in Functions** — Expanded stdlib with full module namespaces:
  - `math.*` — 38 functions (sin, cos, log, factorial, gcd, mean, TAU…)
  - `fs.*` — 20 functions (read, write, exists, copy, list_dir, size…)
  - `os.*` — 10 functions (env_get, system, popen, name, arch, pid…)
  - `json.*` — encode, encode_pretty, decode (pure Rust parser)
  - `crypto.*` — sha256 (real FIPS 180-4), base64_encode/decode, md5
  - `date.*` — now, year, month, day, hour, minute, unix
  - `random.*` — random, randint, choice, uuid, sample
- **Android/Termux Guide** — See `docs/TERMUX.md`

| Feature | 🐢 v1.0.2 | 🚀 v1.0.3 |
|:---|:---:|:---:|
| VM Safety | ❌ `unsafe transmute` | ✅ Safe `TryFrom` |
| `break` / `continue` | ❌ Broken | ✅ Fixed (`stop` / `skip`) |
| `in` operator | ❌ Wrong result | ✅ Real containment check |
| `typeof` | ❌ Always "unknown" | ✅ Returns real type |
| Inline code execution | ❌ Not possible | ✅ `tech eval "..."` |
| Built-in functions | ~40 | ✅ **150+** in 7 modules |
| Windows PATH safety | ❌ Could truncate | ✅ Fixed |

---

The `v1.0.4.3` version is a massive leap from the original `v1.0.1`. Here is why you should upgrade immediately:

| Feature | 🐢 v1.0.1 (Legacy) | 🚀 v1.0.4.3 (Latest) | Impact |
|:---|:---:|:---:|:---|
| **Engine** | Python Wrapper | ✅ **Native Rust VM** | No Python needed! |
| **Speed** | 🐌 Sluggish | ✅ **Ultra Fast (2.9s / 1M loops)** | Professional performance |
| **Safety** | Crashing on errors | ✅ **Panic Recovery (Try/Catch)** | Apps don't crash randomly |
| **StdLib** | < 10 functions | ✅ **180+ Functions** | Batteries included |
| **Animation** | None | ✅ **Cinema Edition Studio** | High-end motion design |
| **Installation** | Hard (ENV issues) | ✅ **One-Click Setup.exe** | Zero effort install |
| **VS Code** | Basic Syntax | ✅ **Smart Snippets + Icons** | Better DX |

---

## 📚 Documentation (Quick Links)

| Document | Direct Link | Description |
|:---|:---|:---|
| **Quick Start** | [📂 QUICKSTART.md](docs/QUICKSTART.md) | Simple step-by-step install for all platforms |
| **Cheat Sheet** | [📜 REFERENCE.md](docs/REFERENCE.md) | All keywords, functions, and syntax at a glance |
| **Standard Library** | [🗃️ STDLIB_REFERENCE.md](docs/STDLIB_REFERENCE.md) | **Latest** — All 180+ built-in functions by module |
| **Web Module** | [🌐 WEB_MODULE.md](docs/WEB_MODULE.md) | How to build websites with TechScript |
| **Termux / Android** | [📱 TERMUX.md](docs/TERMUX.md) | Install and run on Android via Termux |
| **Examples** | [🚀 examples/](examples/) | Explore 20+ ready-to-run `.txs` programs |

---

## 👨‍💻 Made by Tcode-Motion

<div align="center">

**Tanmoy — Tcode-Motion**

*Building languages, AI systems, and the future — one project at a time.*

| 🔥 Project | 📖 Description |
|:---|:---|
| 🐉 **TechScript** | A modern scripting language — Native Rust VM + web builder |
| 🧠 **Project JARVIS** | Personal AI assistant built in Python |
| 💻 **Stark OS** | Sci-Fi UI for web environments |
| 🎨 **3D Visuals** | WebGL particle systems + Three.js experiences |
| 🤖 **AR Keyboard** | Hand-gesture virtual keyboard with OpenCV + MediaPipe |

[![GitHub](https://img.shields.io/badge/GitHub-Tcode--Motion-181717?style=for-the-badge&logo=github)](https://github.com/Tcode-Motion)
[![YouTube](https://img.shields.io/badge/YouTube-@sachkaswitch-FF0000?style=for-the-badge&logo=youtube)](https://youtube.com/@sachkaswitch)

*"Predict the future by coding it." ⚡*

</div>

---

## 📄 License

MIT License — free to use, share, and modify. See [LICENSE](LICENSE).

---

<div align="center">
  <img src="assets/logo.png" alt="TechScript Dragon" width="80"/>
  <br/><br/>
  <strong>Made with 🐉 by Tcode-Motion</strong>
</div>

<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:7c3aed,45:1a0a40,80:0f0820,100:0d0d0d&height=140&section=footer&text=🐉%20TechScript%20—%20Code%20the%20Future&fontSize=22&fontColor=c084fc&animation=fadeIn&fontAlignY=62" width="100%"/>

</div>